// FabQC Export - ماکروی تکلا 2024 برای خروجی گرفتن از قطعه/اسمبلی انتخاب‌شده (هندسه‌ی دقیق + سوراخ‌ها)
// خروجی: فایل FabQC_export.fabqc روی Desktop که در برنامه‌ی Fab QC AR باز می‌شود.
using System;
using System.Collections;
using System.Globalization;
using System.IO;
using System.Text;
using Tekla.Structures.Geometry3d;
using Tekla.Structures.Model;
using Tekla.Structures.Model.UI;

namespace Tekla.Technology.Akit.UserScript
{
    public class Script
    {
        static StringBuilder sb;
        static Hashtable done;
        static int partCount;

        static string F(double v)
        {
            return v.ToString("0.##", CultureInfo.InvariantCulture);
        }

        static string Clean(string s)
        {
            if (s == null) return "";
            return s.Replace('\t', ' ').Replace('\r', ' ').Replace('\n', ' ');
        }

        static string Key(Point a, Point b)
        {
            string ka = Math.Round(a.X, 1).ToString("0.0", CultureInfo.InvariantCulture) + "," + Math.Round(a.Y, 1).ToString("0.0", CultureInfo.InvariantCulture) + "," + Math.Round(a.Z, 1).ToString("0.0", CultureInfo.InvariantCulture);
            string kb = Math.Round(b.X, 1).ToString("0.0", CultureInfo.InvariantCulture) + "," + Math.Round(b.Y, 1).ToString("0.0", CultureInfo.InvariantCulture) + "," + Math.Round(b.Z, 1).ToString("0.0", CultureInfo.InvariantCulture);
            if (string.CompareOrdinal(ka, kb) < 0) return ka + "|" + kb;
            return kb + "|" + ka;
        }

        static string Line(char tag, Point a, Point b)
        {
            return tag + "\t" + F(a.X) + " " + F(a.Y) + " " + F(a.Z) + " " + F(b.X) + " " + F(b.Y) + " " + F(b.Z) + "\n";
        }

        // آیا حلقه دایره‌ی کوچک است؟ (سوراخ)
        static bool IsCircle(ArrayList pts)
        {
            int n = pts.Count;
            if (n < 8) return false;
            double cx = 0, cy = 0, cz = 0;
            foreach (object o in pts)
            {
                Point p = (Point)o;
                cx += p.X; cy += p.Y; cz += p.Z;
            }
            cx /= n; cy /= n; cz /= n;
            double sum = 0, mn = double.MaxValue, mx = 0;
            double[] r = new double[n];
            for (int i = 0; i < n; i++)
            {
                Point p = (Point)pts[i];
                double d = Math.Sqrt((p.X - cx) * (p.X - cx) + (p.Y - cy) * (p.Y - cy) + (p.Z - cz) * (p.Z - cz));
                r[i] = d; sum += d;
                if (d < mn) mn = d;
                if (d > mx) mx = d;
            }
            double avg = sum / n;
            if (avg > 60.0 || avg < 2.0) return false;
            return (mx - mn) / avg < 0.06;
        }

        static void AddPart(Part p)
        {
            if (p == null) return;
            string id = p.Identifier.ID.ToString();
            if (done.ContainsKey(id)) return;
            done[id] = true;

            Tekla.Structures.Solid.Solid solid = p.GetSolid();
            if (solid == null) return;

            sb.Append("P\t").Append(Clean(p.Name)).Append("\t").Append(Clean(p.Profile.ProfileString)).Append("\n");
            partCount++;

            Hashtable edges = new Hashtable();   // key -> object[] { Point a, Point b, Vector n, int count, bool dropped }
            StringBuilder holes = new StringBuilder();

            IEnumerator fe = solid.GetFaceEnumerator();
            while (fe.MoveNext())
            {
                Tekla.Structures.Solid.Face face = (Tekla.Structures.Solid.Face)fe.Current;
                Vector nrm = face.Normal;
                int loopIndex = 0;
                IEnumerator le = face.GetLoopEnumerator();
                while (le.MoveNext())
                {
                    Tekla.Structures.Solid.Loop loop = (Tekla.Structures.Solid.Loop)le.Current;
                    ArrayList pts = new ArrayList();
                    IEnumerator ve = loop.GetVertexEnumerator();
                    while (ve.MoveNext())
                    {
                        pts.Add((Point)ve.Current);
                    }
                    int n = pts.Count;
                    if (n < 2) { loopIndex++; continue; }

                    // حلقه‌ی داخلی دایره‌ای = سوراخ
                    if (loopIndex > 0 && IsCircle(pts))
                    {
                        for (int i = 0; i < n; i++)
                        {
                            Point a = (Point)pts[i];
                            Point b = (Point)pts[(i + 1) % n];
                            holes.Append(Line('H', a, b));
                        }
                    }

                    for (int i = 0; i < n; i++)
                    {
                        Point a = (Point)pts[i];
                        Point b = (Point)pts[(i + 1) % n];
                        string k = Key(a, b);
                        if (!edges.ContainsKey(k))
                        {
                            edges[k] = new object[] { a, b, nrm, 1 };
                        }
                        else
                        {
                            object[] e = (object[])edges[k];
                            Vector n1 = (Vector)e[2];
                            double dot = n1.X * nrm.X + n1.Y * nrm.Y + n1.Z * nrm.Z;
                            double l1 = Math.Sqrt(n1.X * n1.X + n1.Y * n1.Y + n1.Z * n1.Z);
                            double l2 = Math.Sqrt(nrm.X * nrm.X + nrm.Y * nrm.Y + nrm.Z * nrm.Z);
                            if (l1 > 0 && l2 > 0) dot /= (l1 * l2);
                            // دو وجه تقریباً هم‌صفحه (لبه‌ی داخلی تسلسل سطح منحنی) حذف می‌شود
                            if (dot > 0.98) e[3] = 0; else e[3] = 2;
                        }
                    }
                    loopIndex++;
                }
            }

            foreach (DictionaryEntry de in edges)
            {
                object[] e = (object[])de.Value;
                int c = (int)e[3];
                if (c == 0) continue;
                sb.Append(Line('E', (Point)e[0], (Point)e[1]));
            }
            sb.Append(holes.ToString());
        }

        static void AddObject(ModelObject mo)
        {
            Assembly asm = mo as Assembly;
            if (asm != null)
            {
                AddPart(asm.GetMainPart() as Part);
                ArrayList sec = asm.GetSecondaries();
                if (sec != null)
                {
                    foreach (object o in sec)
                    {
                        AddPart(o as Part);
                    }
                }
                return;
            }
            AddPart(mo as Part);
        }

        public static void Run(Tekla.Technology.Akit.IScript akit)
        {
            sb = new StringBuilder();
            done = new Hashtable();
            partCount = 0;
            sb.Append("FABQC 1 mm\n");

            ModelObjectSelector selector = new ModelObjectSelector();
            ModelObjectEnumerator en = selector.GetSelectedObjects();
            while (en.MoveNext())
            {
                AddObject(en.Current);
            }

            if (partCount == 0)
            {
                Tekla.Structures.Model.Operations.Operation.DisplayPrompt("FabQC: ابتدا یک قطعه یا اسمبلی را انتخاب کنید.");
                return;
            }

            string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "FabQC_export.fabqc");
            File.WriteAllText(path, sb.ToString(), new UTF8Encoding(false));
            Tekla.Structures.Model.Operations.Operation.DisplayPrompt("FabQC: " + partCount.ToString() + " part -> " + path);
        }
    }
}
