package ir.fabsteel.arqc

import android.Manifest
import android.animation.ObjectAnimator
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.AspectRatio
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

// ---------- ریاضی ماتریس 3x3 (سطری) ----------
private fun mmul(a: FloatArray, b: FloatArray): FloatArray {
    val r = FloatArray(9)
    for (i in 0..2) for (j in 0..2) {
        var s = 0f
        for (k in 0..2) s += a[i * 3 + k] * b[k * 3 + j]
        r[i * 3 + j] = s
    }
    return r
}
private fun mT(a: FloatArray) = floatArrayOf(a[0], a[3], a[6], a[1], a[4], a[7], a[2], a[5], a[8])
private fun mv(a: FloatArray, x: Float, y: Float, z: Float) = floatArrayOf(
    a[0] * x + a[1] * y + a[2] * z,
    a[3] * x + a[4] * y + a[5] * z,
    a[6] * x + a[7] * y + a[8] * z
)
private fun rotX(t: Float): FloatArray { val c = cos(t); val s = sin(t); return floatArrayOf(1f, 0f, 0f, 0f, c, -s, 0f, s, c) }
private fun rotY(t: Float): FloatArray { val c = cos(t); val s = sin(t); return floatArrayOf(c, 0f, s, 0f, 1f, 0f, -s, 0f, c) }
private fun rotZ(t: Float): FloatArray { val c = cos(t); val s = sin(t); return floatArrayOf(c, -s, 0f, s, c, 0f, 0f, 0f, 1f) }

class CamPose(val m: FloatArray, val px: Float, val py: Float, val pz: Float, val w: Int, val h: Int, val f: Float)

/** نمای روی دوربین: مدل را رسم می‌کند و با انگشت قابل تنظیم است؛ بعد از Fix با ژیروسکوپ ثابت می‌ماند. */
class CamOverlay(ctx: Context) : View(ctx) {
    private var model: IfcModel? = null
    var segs: List<FloatArray> = emptyList(); private set      // پاره‌خط‌های هر عضو (نسبت به مرکز)
    var samples: List<FloatArray> = emptyList(); private set   // نقاط نمونه‌ی هر عضو
    var isHole: BooleanArray = BooleanArray(0); private set
    var names: List<String> = emptyList(); private set
    @Volatile var redFlags: BooleanArray = BooleanArray(0)
    @Volatile var rot: FloatArray? = null

    private var cx = 0f; private var cy = 0f; private var cz = 0f
    private var radius = 1f
    private var yaw = 0f; private var pitch = 0f; private var roll = 0f
    private var tx = 0f; private var ty = 0f; private var dist = 2f
    private var needInit = true
    var moveMode = true
    @Volatile var fixed = false; private set
    private var fixR: FloatArray? = null
    private var fixMc = floatArrayOf(1f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 1f)
    private var fixP = floatArrayOf(0f, 0f, 0f)

    private val okPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF39D0FF.toInt(); strokeWidth = 2.5f; style = Paint.Style.STROKE }
    private val holePaint = Paint(okPaint).apply { color = 0xFFFFC107.toInt() }
    private val redPaint = Paint(okPaint).apply { color = 0xFFFF2B2B.toInt(); strokeWidth = 5f }
    private var okBuf = FloatArray(0); private var holeBuf = FloatArray(0); private var redBuf = FloatArray(0)

    private val sd = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            if (fixed) return true
            dist = (dist / d.scaleFactor).coerceIn(0.05f, 200f); invalidate(); return true
        }
    })
    private var lx = 0f; private var ly = 0f; private var lastAng = 0f

    fun setModel(m: IfcModel?) {
        model = m
        if (m == null) { segs = emptyList(); samples = emptyList(); isHole = BooleanArray(0); names = emptyList(); invalidate(); return }
        val s = m.sizeM
        cx = s[0] / 2; cy = s[1] / 2; cz = s[2] / 2
        radius = max(0.001f, sqrt(s[0] * s[0] + s[1] * s[1] + s[2] * s[2]) / 2)
        var total = 0L
        for (mb in m.members) total += mb.edges.size / 6
        val step = max(1, (total / 120000).toInt())
        val sg = ArrayList<FloatArray>(); val sm = ArrayList<FloatArray>()
        val hl = BooleanArray(m.members.size); val nm = ArrayList<String>()
        var k = 0
        for ((i, mb) in m.members.withIndex()) {
            val o = ArrayList<Float>()
            var j = 0
            while (j + 5 < mb.edges.size) {
                if (k++ % step == 0) {
                    o.add(mb.edges[j] - cx); o.add(mb.edges[j + 1] - cy); o.add(mb.edges[j + 2] - cz)
                    o.add(mb.edges[j + 3] - cx); o.add(mb.edges[j + 4] - cy); o.add(mb.edges[j + 5] - cz)
                }
                j += 6
            }
            val arr = o.toFloatArray()
            sg.add(arr)
            // نقاط نمونه: وسط هر پاره‌خط، حداکثر 48 نقطه
            val nSeg = arr.size / 6
            val st = max(1, nSeg / 48)
            val p = ArrayList<Float>()
            var q = 0
            while (q < nSeg) {
                p.add((arr[q * 6] + arr[q * 6 + 3]) / 2); p.add((arr[q * 6 + 1] + arr[q * 6 + 4]) / 2); p.add((arr[q * 6 + 2] + arr[q * 6 + 5]) / 2)
                q += st
            }
            sm.add(p.toFloatArray())
            hl[i] = mb.isHole; nm.add(mb.name)
        }
        segs = sg; samples = sm; isHole = hl; names = nm
        var mx = 0
        for (a in sg) mx += a.size / 6
        okBuf = FloatArray(mx * 4); holeBuf = FloatArray(mx * 4); redBuf = FloatArray(mx * 4)
        redFlags = BooleanArray(m.members.size)
        yaw = 0.6f; pitch = 0.35f; roll = 0f; tx = 0f; ty = 0f
        needInit = true; fixed = false
        invalidate()
    }

    fun focal() = 0.73f * max(width, 1)

    private fun baseMc() = mmul(rotZ(roll), mmul(rotX(pitch), rotY(yaw)))

    fun pose(): CamPose {
        val f = focal()
        val r = rot; val r0 = fixR
        val mc: FloatArray; val pc: FloatArray
        if (fixed && r != null && r0 != null) {
            val rt = mT(r)
            mc = mmul(mmul(rt, r0), fixMc)
            val pw = mv(r0, fixP[0], fixP[1], fixP[2])
            pc = mv(rt, pw[0], pw[1], pw[2])
        } else if (fixed) {
            mc = fixMc; pc = fixP
        } else {
            mc = baseMc(); pc = floatArrayOf(tx, ty, -dist)
        }
        return CamPose(mc, pc[0], pc[1], pc[2], width, height, f)
    }

    fun lock() {
        fixMc = baseMc(); fixP = floatArrayOf(tx, ty, -dist)
        fixR = rot?.clone()
        fixed = true; invalidate()
    }
    fun unlock() {
        // ادامه از آخرین حالت دیده‌شده
        if (fixed) {
            val p = pose()
            tx = p.px; ty = p.py; dist = max(0.05f, -p.pz)
        }
        fixed = false; invalidate()
    }
    fun pxPerMm(): Float { val p = pose(); return p.f / (max(0.05f, abs(p.pz)) * 1000f) }

    fun nudgeYaw(deg: Float) { if (!fixed) { yaw += Math.toRadians(deg.toDouble()).toFloat(); invalidate() } }

    override fun onDraw(c: Canvas) {
        val m = model ?: return
        if (width == 0) return
        if (needInit) {
            dist = max(0.2f, radius * focal() / (0.4f * min(width, height)))
            needInit = false
        }
        val p = pose()
        val flags = redFlags
        var no = 0; var nh = 0; var nr = 0
        val hw = width / 2f; val hh = height / 2f
        for (i in segs.indices) {
            val a = segs[i]
            val red = i < flags.size && flags[i]
            var j = 0
            while (j + 5 < a.size) {
                val v1 = mv(p.m, a[j], a[j + 1], a[j + 2])
                val v2 = mv(p.m, a[j + 3], a[j + 4], a[j + 5])
                val z1 = -(v1[2] + p.pz); val z2 = -(v2[2] + p.pz)
                if (z1 > 0.05f && z2 > 0.05f) {
                    val x1 = hw + p.f * (v1[0] + p.px) / z1; val y1 = hh - p.f * (v1[1] + p.py) / z1
                    val x2 = hw + p.f * (v2[0] + p.px) / z2; val y2 = hh - p.f * (v2[1] + p.py) / z2
                    if (red) { redBuf[nr++] = x1; redBuf[nr++] = y1; redBuf[nr++] = x2; redBuf[nr++] = y2 }
                    else if (isHole[i]) { holeBuf[nh++] = x1; holeBuf[nh++] = y1; holeBuf[nh++] = x2; holeBuf[nh++] = y2 }
                    else { okBuf[no++] = x1; okBuf[no++] = y1; okBuf[no++] = x2; okBuf[no++] = y2 }
                }
                j += 6
            }
        }
        c.drawLines(okBuf, 0, no, okPaint)
        c.drawLines(holeBuf, 0, nh, holePaint)
        c.drawLines(redBuf, 0, nr, redPaint)
        if (m.members.isEmpty()) return
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (fixed) return false
        sd.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (e.pointerCount == 2) lastAng = atan2(e.getY(1) - e.getY(0), e.getX(1) - e.getX(0))
                lx = e.x; ly = e.y
            }
            MotionEvent.ACTION_MOVE -> {
                if (e.pointerCount == 1 && !sd.isInProgress) {
                    val dx = e.x - lx; val dy = e.y - ly; lx = e.x; ly = e.y
                    if (moveMode) {
                        val k = dist / focal()
                        tx += dx * k; ty -= dy * k
                    } else {
                        yaw += dx * 0.008f; pitch += dy * 0.008f
                    }
                    invalidate()
                } else if (e.pointerCount == 2) {
                    val ang = atan2(e.getY(1) - e.getY(0), e.getX(1) - e.getX(0))
                    if (!moveMode) roll += (ang - lastAng)
                    lastAng = ang
                    lx = e.x; ly = e.y
                    invalidate()
                }
            }
            MotionEvent.ACTION_POINTER_UP -> { lx = e.x; ly = e.y }
        }
        return true
    }
}

class QcCamActivity : AppCompatActivity(), SensorEventListener {
    private lateinit var previewView: PreviewView
    private lateinit var overlay: CamOverlay
    private lateinit var alarm: Alarm
    private lateinit var logo: ImageView
    private lateinit var tvFix: TextView
    private lateinit var tvMode: TextView
    private lateinit var tvTolM: TextView
    private lateinit var tvTolH: TextView
    private lateinit var tvMute: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvHint: TextView
    private lateinit var loadingTv: TextView
    private var blink: ObjectAnimator? = null
    private var tolM = 5f
    private var tolH = 3f
    private val exec = Executors.newSingleThreadExecutor()
    private var lastQc = 0L
    private var badCount = IntArray(0)
    private var goodCount = IntArray(0)
    private var sensorMgr: SensorManager? = null

    private val pickIfc = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            loadingTv.visibility = View.VISIBLE
            loadingTv.text = "در حال خواندن فایل…"
            IfcLoader.load(this, uri, { loadingTv.text = it }) { m, err ->
                loadingTv.visibility = View.GONE
                if (m != null) { setModel(m) }
                else Toast.makeText(this, "خطا در خواندن IFC: $err", Toast.LENGTH_LONG).show()
            }
        }
    }
    private val camPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startCamera() else Toast.makeText(this, "بدون اجازه‌ی دوربین، برنامه کار نمی‌کند", Toast.LENGTH_LONG).show()
    }

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()

    private fun mk(t: String, sp: Float = 17f, click: () -> Unit): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = sp
        tv.setTextColor(ContextCompat.getColor(this, R.color.btn_text))
        tv.setBackgroundResource(R.drawable.bg_btn3d)
        tv.gravity = Gravity.CENTER
        tv.setPadding(dp(14f), dp(10f), dp(14f), dp(10f))
        tv.isClickable = true
        tv.setOnClickListener { click() }
        return tv
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        val sp = getSharedPreferences("fabsteel", MODE_PRIVATE)
        tolM = sp.getFloat("camTolM", 5f); tolH = sp.getFloat("camTolH", 3f)
        alarm = Alarm(this)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        previewView = PreviewView(this)
        previewView.scaleType = PreviewView.ScaleType.FILL_CENTER
        root.addView(previewView, FrameLayout.LayoutParams(-1, -1))
        overlay = CamOverlay(this)
        root.addView(overlay, FrameLayout.LayoutParams(-1, -1))

        // ستون دکمه‌ها (چپ)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        fun add(v: View) {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(6f); col.addView(v, lp)
        }
        add(mk("Tekla Upload IFC", 18f) { pickIfc.launch(arrayOf("*/*")) })
        tvMode = mk("حالت: جابه‌جایی", 16f) {
            overlay.moveMode = !overlay.moveMode
            tvMode.text = if (overlay.moveMode) "حالت: جابه‌جایی" else "حالت: چرخش"
        }
        add(tvMode)
        tvTolM = mk("", 16f) { askNumber("دقت اجزا (mm)", tolM) { tolM = it; sp.edit().putFloat("camTolM", it).apply(); refreshTol() } }
        add(tvTolM)
        tvTolH = mk("", 16f) { askNumber("دقت سوراخ‌کاری (mm)", tolH) { tolH = it; sp.edit().putFloat("camTolH", it).apply(); refreshTol() } }
        add(tvTolH)
        tvMute = mk("🔊 صدا", 16f) {
            alarm.muted = !alarm.muted
            tvMute.text = if (alarm.muted) "🔇 بی‌صدا" else "🔊 صدا"
        }
        add(tvMute)
        add(mk("⌂ منو", 16f) { finish() })
        val lpc = FrameLayout.LayoutParams(-2, -2, Gravity.START or Gravity.TOP)
        lpc.leftMargin = dp(10f); lpc.topMargin = dp(8f)
        root.addView(col, lpc)

        // لوگو بالا-راست (چشمک‌زن هنگام مغایرت)
        logo = ImageView(this)
        logo.setImageResource(R.drawable.fabsteel_logo)
        logo.adjustViewBounds = true
        val lpl = FrameLayout.LayoutParams(dp(150f), -2, Gravity.END or Gravity.TOP)
        lpl.topMargin = dp(8f); lpl.rightMargin = dp(10f)
        root.addView(logo, lpl)

        // پنل وضعیت پایین-راست
        tvStatus = TextView(this)
        tvStatus.setTextColor(Color.WHITE); tvStatus.textSize = 16f
        tvStatus.setBackgroundColor(0xAA000000.toInt())
        tvStatus.setPadding(dp(12f), dp(8f), dp(12f), dp(8f))
        tvStatus.text = "مدل بارگذاری نشده"
        val lps = FrameLayout.LayoutParams(dp(260f), -2, Gravity.END or Gravity.BOTTOM)
        lps.rightMargin = dp(10f); lps.bottomMargin = dp(10f)
        root.addView(tvStatus, lps)

        // راهنما
        tvHint = TextView(this)
        tvHint.setTextColor(Color.WHITE); tvHint.textSize = 14f
        tvHint.setBackgroundColor(0x99000000.toInt())
        tvHint.setPadding(dp(10f), dp(6f), dp(10f), dp(6f))
        tvHint.gravity = Gravity.CENTER
        val lph = FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM)
        lph.bottomMargin = dp(86f)
        root.addView(tvHint, lph)

        // دکمه‌ی Fix
        tvFix = mk("FIX", 26f) { toggleFix() }
        tvFix.setPadding(dp(40f), dp(14f), dp(40f), dp(14f))
        val lpf = FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM)
        lpf.bottomMargin = dp(14f)
        root.addView(tvFix, lpf)

        loadingTv = TextView(this)
        loadingTv.setTextColor(Color.WHITE); loadingTv.textSize = 20f
        loadingTv.setBackgroundColor(0xCC000000.toInt())
        loadingTv.setPadding(dp(20f), dp(14f), dp(20f), dp(14f))
        loadingTv.visibility = View.GONE
        root.addView(loadingTv, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        setContentView(root)
        refreshTol(); refreshHint()
        ModelStore.model?.let { setModel(it) }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else camPerm.launch(Manifest.permission.CAMERA)
    }

    private fun refreshTol() {
        tvTolM.text = "دقت اجزا: ${trim(tolM)} mm"
        tvTolH.text = "دقت سوراخ: ${trim(tolH)} mm"
    }
    private fun trim(v: Float) = if (v == v.toInt().toFloat()) v.toInt().toString() else v.toString()

    private fun refreshHint() {
        tvHint.text = when {
            overlay.fixed -> "قفل شده؛ برای تنظیم دوباره، Unfix بزن"
            ModelStore.model == null -> "اول خروجی IFC تکلا را آپلود کن"
            else -> "مدل را با یک انگشت بکش، با دو انگشت زوم کن؛ روی قطعه بگذار و FIX بزن"
        }
        tvFix.text = if (overlay.fixed) "UNFIX" else "FIX"
    }

    private fun setModel(m: IfcModel) {
        overlay.setModel(m)
        badCount = IntArray(m.members.size); goodCount = IntArray(m.members.size)
        tvStatus.text = "${m.members.size} قطعه — مدل را روی قطعه بگذار"
        stopAlarm(); refreshHint()
        if (m.members.size > 3000) Toast.makeText(this, "این فایل کل پروژه است؛ برای QC فقط یک قطعه را خروجی بگیر", Toast.LENGTH_LONG).show()
    }

    private fun toggleFix() {
        if (ModelStore.model == null) { Toast.makeText(this, "اول خروجی IFC تکلا را آپلود کن", Toast.LENGTH_SHORT).show(); return }
        if (overlay.fixed) { overlay.unlock(); stopAlarm(); overlay.redFlags = BooleanArray(ModelStore.model!!.members.size) }
        else {
            overlay.lock()
            badCount = IntArray(ModelStore.model!!.members.size); goodCount = IntArray(ModelStore.model!!.members.size)
        }
        refreshHint()
    }

    private fun askNumber(title: String, cur: Float, ok: (Float) -> Unit) {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        et.setText(trim(cur))
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ ->
                val v = et.text.toString().replace(',', '.').toFloatOrNull()
                if (v != null && v > 0f && v < 1000f) ok(v)
            }.setNegativeButton("Cancel", null).show()
    }

    // ---------- دوربین ----------
    @Suppress("DEPRECATION")
    private fun startCamera() {
        val fut = ProcessCameraProvider.getInstance(this)
        fut.addListener({
            try {
                val provider = fut.get()
                val preview = Preview.Builder().setTargetAspectRatio(AspectRatio.RATIO_4_3).build()
                preview.setSurfaceProvider(previewView.surfaceProvider)
                val analysis = ImageAnalysis.Builder()
                    .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(exec) { img ->
                    try { analyze(img) } catch (t: Throwable) { } finally { img.close() }
                }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (t: Throwable) {
                Toast.makeText(this, "دوربین باز نشد: ${t.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    // ---------- تحلیل: لبه‌های مدل در مقابل لبه‌های تصویر ----------
    private fun analyze(img: ImageProxy) {
        val now = System.currentTimeMillis()
        if (!overlay.fixed || now - lastQc < 500) return
        val model = ModelStore.model ?: return
        val n = model.members.size
        if (n == 0 || overlay.width == 0) return
        val rotDeg = img.imageInfo.rotationDegrees
        if (rotDeg != 0 && rotDeg != 180) return
        lastQc = now
        val plane = img.planes[0]
        val buf = plane.buffer
        val rs = plane.rowStride
        val w = img.width; val h = img.height
        fun lum(x: Int, y: Int): Int = buf.get(y * rs + x).toInt() and 0xFF
        fun grad(x: Int, y: Int): Int =
            abs(lum(x + 1, y) - lum(x - 1, y)) + abs(lum(x, y + 1) - lum(x, y - 1))

        // آستانه‌ی لبه از میانگین گرادیان تصویر
        var sum = 0L; var cnt = 0
        var yy = 2
        while (yy < h - 2) {
            var xx = 2
            while (xx < w - 2) { sum += grad(xx, yy); cnt++; xx += 16 }
            yy += 16
        }
        val thr = max(24f, 2.2f * (sum.toFloat() / max(1, cnt)))

        val p = overlay.pose()
        val s = max(p.w / w.toFloat(), p.h / h.toFloat())
        val ox = (p.w - w * s) / 2f; val oy = (p.h - h * s) / 2f
        val pxMm = p.f / (max(0.05f, abs(p.pz)) * 1000f)
        val ratio = FloatArray(n) { -1f }
        for (i in 0 until n) {
            val sm = overlay.samples.getOrNull(i) ?: continue
            val tol = if (overlay.isHole[i]) tolH else tolM
            val rImg = ((tol * pxMm) / s).roundToInt().coerceIn(2, 14)
            var counted = 0; var hits = 0
            var k = 0
            while (k + 2 < sm.size) {
                val v = mv(p.m, sm[k], sm[k + 1], sm[k + 2])
                k += 3
                val z = -(v[2] + p.pz)
                if (z < 0.05f) continue
                val sx = p.w / 2f + p.f * (v[0] + p.px) / z
                val sy = p.h / 2f - p.f * (v[1] + p.py) / z
                var ix = ((sx - ox) / s).toInt(); var iy = ((sy - oy) / s).toInt()
                if (rotDeg == 180) { ix = w - 1 - ix; iy = h - 1 - iy }
                if (ix < rImg + 1 || iy < rImg + 1 || ix >= w - rImg - 1 || iy >= h - rImg - 1) continue
                counted++
                var found = false
                var dy = -rImg
                while (dy <= rImg && !found) {
                    var dx = -rImg
                    while (dx <= rImg) {
                        if (grad(ix + dx, iy + dy) > thr) { found = true; break }
                        dx += 2
                    }
                    dy += 2
                }
                if (found) hits++
            }
            if (counted >= 4) ratio[i] = hits.toFloat() / counted
        }
        val valid = ratio.filter { it >= 0f }.sorted()
        if (valid.size < 2) { runOnUiThread { tvStatus.text = "مدل در تصویر دیده نمی‌شود؛ دوربین را به قطعه بگیر" }; return }
        val median = valid[valid.size / 2]
        val reds = BooleanArray(n)
        var redCount = 0
        val redNames = ArrayList<String>()
        val poorAlign = median < 0.12f
        for (i in 0 until n) {
            if (badCount.size <= i) break
            if (ratio[i] < 0f) { reds[i] = overlay.redFlags.getOrElse(i) { false }; if (reds[i]) redCount++; continue }
            val bad = !poorAlign && ratio[i] < 0.45f * median && ratio[i] < 0.3f
            if (bad) { badCount[i]++; goodCount[i] = 0 } else { goodCount[i]++; badCount[i] = 0 }
            val prev = overlay.redFlags.getOrElse(i) { false }
            reds[i] = if (!prev) badCount[i] >= 2 else goodCount[i] < 2
            if (reds[i]) { redCount++; if (redNames.size < 4) redNames.add(model.members[i].name) }
        }
        val okPct = ((n - redCount) * 100f / n).roundToInt()
        runOnUiThread {
            overlay.redFlags = reds
            overlay.invalidate()
            tvStatus.text = when {
                poorAlign -> "هم‌ترازی مدل با تصویر ضعیف است؛ Unfix بزن و مدل را دقیق‌تر روی قطعه بگذار"
                redCount > 0 -> "مغایرت: $redCount عضو\n" + redNames.joinToString("\n") + "\nتطابق $okPct%"
                else -> "تطابق $okPct% ✓"
            }
            if (redCount > 0 && !poorAlign) startAlarm() else stopAlarm()
        }
    }

    private fun startAlarm() {
        alarm.start()
        if (blink == null) {
            blink = ObjectAnimator.ofFloat(logo, View.ALPHA, 1f, 0.1f).apply {
                duration = 350; repeatMode = ObjectAnimator.REVERSE; repeatCount = ObjectAnimator.INFINITE; start()
            }
        }
    }
    private fun stopAlarm() {
        alarm.stop()
        blink?.cancel(); blink = null
        logo.alpha = 1f
    }

    // ---------- سنسور ----------
    override fun onResume() {
        super.onResume()
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sensorMgr = sm
        val s = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR) ?: sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        if (s != null) sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME)
    }
    override fun onPause() {
        sensorMgr?.unregisterListener(this)
        stopAlarm()
        super.onPause()
    }
    override fun onDestroy() { stopAlarm(); exec.shutdown(); super.onDestroy() }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    @Suppress("DEPRECATION")
    override fun onSensorChanged(e: SensorEvent) {
        val r9 = FloatArray(9)
        SensorManager.getRotationMatrixFromVector(r9, e.values)
        val out = FloatArray(9)
        val rotation = windowManager.defaultDisplay.rotation
        val ax: Int; val ay: Int
        when (rotation) {
            Surface.ROTATION_90 -> { ax = SensorManager.AXIS_Y; ay = SensorManager.AXIS_MINUS_X }
            Surface.ROTATION_180 -> { ax = SensorManager.AXIS_MINUS_X; ay = SensorManager.AXIS_MINUS_Y }
            Surface.ROTATION_270 -> { ax = SensorManager.AXIS_MINUS_Y; ay = SensorManager.AXIS_X }
            else -> { ax = SensorManager.AXIS_X; ay = SensorManager.AXIS_Y }
        }
        SensorManager.remapCoordinateSystem(r9, ax, ay, out)
        overlay.rot = out
        if (overlay.fixed) overlay.invalidate()
    }
}
