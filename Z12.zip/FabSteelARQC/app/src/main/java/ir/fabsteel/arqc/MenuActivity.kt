package ir.fabsteel.arqc

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate

/** منوی اصلی؛ تصویر طرح کاربر + نواحی لمسی روی دکمه‌ها (مختصات به صورت کسری از تصویر). */
class MenuView(ctx: Context, private val onHit: (Int) -> Unit) : View(ctx) {
    private val bmp = BitmapFactory.decodeResource(resources, R.drawable.menu_bg)
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val dim = Paint().apply { color = Color.argb(150, 0, 0, 0) }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL; color = Color.argb(70, 255, 255, 255)
    }
    private val dst = RectF()
    private var pressed = -1

    // left, top, right, bottom بر حسب کسری از عرض/ارتفاع تصویر (1536x1024)
    private val zones = arrayOf(
        floatArrayOf(0.060f, 0.395f, 0.315f, 0.790f), // 0 PDF Reader
        floatArrayOf(0.330f, 0.380f, 0.590f, 0.790f), // 1 3D PDF Reader
        floatArrayOf(0.600f, 0.405f, 0.945f, 0.800f), // 2 QC AR
        floatArrayOf(0.790f, 0.020f, 0.860f, 0.120f), // 3 settings
        floatArrayOf(0.860f, 0.020f, 0.930f, 0.120f), // 4 globe
        floatArrayOf(0.930f, 0.020f, 0.965f, 0.120f), // 5 info
        floatArrayOf(0.965f, 0.020f, 1.000f, 0.120f)  // 6 power
    )

    init {
        // آیکن‌های بالا-راست در تصویر: x ≈ 1250,1330,1405,1478 از 1536
        zones[3] = floatArrayOf(0.800f, 0.015f, 0.862f, 0.125f)
        zones[4] = floatArrayOf(0.862f, 0.015f, 0.915f, 0.125f)
        zones[5] = floatArrayOf(0.915f, 0.015f, 0.965f, 0.125f)
        zones[6] = floatArrayOf(0.945f, 0.015f, 1.000f, 0.125f)
        zones[5] = floatArrayOf(0.890f, 0.015f, 0.945f, 0.125f)
        zones[4] = floatArrayOf(0.830f, 0.015f, 0.890f, 0.125f)
        zones[3] = floatArrayOf(0.770f, 0.015f, 0.830f, 0.125f)
    }

    private fun layoutRect() {
        val s = minOf(width / bmp.width.toFloat(), height / bmp.height.toFloat())
        val w = bmp.width * s; val h = bmp.height * s
        dst.set((width - w) / 2f, (height - h) / 2f, (width + w) / 2f, (height + h) / 2f)
    }

    override fun onDraw(c: Canvas) {
        // پس‌زمینه‌ی تیره‌شده‌ی پر کردن کل صفحه
        val s = maxOf(width / bmp.width.toFloat(), height / bmp.height.toFloat())
        val w = bmp.width * s; val h = bmp.height * s
        c.drawBitmap(bmp, null, RectF((width - w) / 2f, (height - h) / 2f, (width + w) / 2f, (height + h) / 2f), paint)
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dim)
        layoutRect()
        c.drawBitmap(bmp, null, dst, paint)
        if (pressed >= 0) c.drawRoundRect(zoneRect(pressed), 30f, 30f, glow)
    }

    private fun zoneRect(i: Int): RectF {
        val z = zones[i]
        return RectF(dst.left + z[0] * dst.width(), dst.top + z[1] * dst.height(),
            dst.left + z[2] * dst.width(), dst.top + z[3] * dst.height())
    }

    private fun hit(x: Float, y: Float): Int {
        for (i in zones.indices.reversed()) if (zoneRect(i).contains(x, y)) return i
        return -1
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { pressed = hit(e.x, e.y); invalidate(); return pressed >= 0 }
            MotionEvent.ACTION_UP -> {
                val h = hit(e.x, e.y); val was = pressed
                pressed = -1; invalidate()
                if (h >= 0 && h == was) { performClick(); onHit(h) }
            }
            MotionEvent.ACTION_CANCEL -> { pressed = -1; invalidate() }
        }
        return true
    }
    override fun performClick(): Boolean { super.performClick(); return true }
}

class MenuActivity : AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        val night = getSharedPreferences("fabsteel", MODE_PRIVATE).getBoolean("night", true)
        AppCompatDelegate.setDefaultNightMode(if (night) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO)
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(MenuView(this) { id ->
            when (id) {
                0 -> startActivity(Intent(this, PdfActivity::class.java))
                1 -> startActivity(Intent(this, Viewer3dActivity::class.java))
                2 -> openQc()
                3 -> askTheme()
                4 -> Toast.makeText(this, "Language: English (فعلاً فقط یک زبان)", Toast.LENGTH_SHORT).show()
                5 -> AlertDialog.Builder(this)
                    .setTitle("Fab QC AR")
                    .setMessage("Smart Quality Control with Augmented Reality\nby Eng Davod Bagheri\nFabSteel\n\nنسخه ۱۰")
                    .setPositiveButton("OK", null).show()
                6 -> finishAffinity()
            }
        })
    }

    private fun openQc() {
        val av = com.google.ar.core.ArCoreApk.getInstance().checkAvailability(this)
        if (av.isTransient) {
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ openQc() }, 400)
            return
        }
        if (av == com.google.ar.core.ArCoreApk.Availability.SUPPORTED_INSTALLED)
            startActivity(Intent(this, MainActivity::class.java))
        else
            startActivity(Intent(this, QcCamActivity::class.java))
    }

    private fun askTheme() {
        val p = getSharedPreferences("fabsteel", MODE_PRIVATE)
        AlertDialog.Builder(this).setTitle("Theme")
            .setItems(arrayOf("تیره (Dark)", "روشن (Light)")) { _, w ->
                p.edit().putBoolean("night", w == 0).apply()
                AppCompatDelegate.setDefaultNightMode(if (w == 0) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO)
            }.show()
    }
}
