package ir.fabsteel.arqc

import android.app.Activity
import android.net.Uri

/** خواندن IFC در پس‌زمینه؛ نتیجه در ModelStore ذخیره می‌شود. */
object IfcLoader {
    fun load(act: Activity, uri: Uri, progress: (String) -> Unit, done: (IfcModel?, String?) -> Unit) {
        Thread {
            try {
                val ins = act.contentResolver.openInputStream(uri) ?: throw IllegalStateException("فایل باز نشد")
                val m = ins.use { IfcParser { msg -> act.runOnUiThread { progress(msg) } }.parse(it) }
                ModelStore.model = m
                act.runOnUiThread { done(m, null) }
            } catch (t: Throwable) {
                act.runOnUiThread { done(null, t.message ?: t.javaClass.simpleName) }
            }
        }.start()
    }
}
