package ir.fabsteel.arqc

import android.graphics.*
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File

/** نمایش‌گر ساده‌ی تصویر با زوم دو انگشتی و جابه‌جایی. */
class ZoomImageView(c: android.content.Context) : View(c) {
    var bitmap: Bitmap? = null
        set(v) { field = v; reset(); invalidate() }
    private val m = Matrix()
    private val p = Paint(Paint.FILTER_BITMAP_FLAG)
    private var lx = 0f; private var ly = 0f
    private val sd = ScaleGestureDetector(c, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            m.postScale(d.scaleFactor, d.scaleFactor, d.focusX, d.focusY); invalidate(); return true
        }
    })
    fun reset() {
        val b = bitmap ?: return
        if (width == 0) return
        m.reset()
        val s = minOf(width / b.width.toFloat(), height / b.height.toFloat())
        m.postScale(s, s); m.postTranslate((width - b.width * s) / 2f, (height - b.height * s) / 2f)
    }
    fun zoom(f: Float) { m.postScale(f, f, width / 2f, height / 2f); invalidate() }
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { reset() }
    override fun onDraw(c: Canvas) { bitmap?.let { c.drawBitmap(it, m, p) } }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        sd.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y }
            MotionEvent.ACTION_MOVE -> if (!sd.isInProgress && e.pointerCount == 1) {
                m.postTranslate(e.x - lx, e.y - ly); lx = e.x; ly = e.y; invalidate()
            } else { lx = e.x; ly = e.y }
            MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_UP -> { lx = e.x; ly = e.y }
        }
        return true
    }
}

class PdfActivity : AppCompatActivity() {
    private var renderer: PdfRenderer? = null
    private var pfd: ParcelFileDescriptor? = null
    private var page = 0
    private lateinit var zv: ZoomImageView
    private lateinit var info: TextView

    private val pick = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) open(uri) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF0A1226.toInt()) }
        zv = ZoomImageView(this)
        root.addView(zv, LinearLayout.LayoutParams(-1, 0, 1f))
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(8, 8, 8, 8) }
        fun btn(t: String, a: () -> Unit) = Button(this).apply {
            text = t; textSize = 18f; setOnClickListener { a() }
        }.also { bar.addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
        btn("📂 PDF") { pick.launch(arrayOf("application/pdf")) }
        btn("◀") { show(page - 1) }
        info = TextView(this).apply { setTextColor(Color.WHITE); textSize = 18f; gravity = Gravity.CENTER; text = "0 / 0"
            setOnClickListener { jump() } }
        bar.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        btn("▶") { show(page + 1) }
        btn("＋") { zv.zoom(1.4f) }
        btn("－") { zv.zoom(1f / 1.4f) }
        btn("⌂") { zv.reset(); zv.invalidate() }
        btn("✕") { finish() }
        root.addView(bar)
        setContentView(root)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
    }

    private fun open(uri: Uri) {
        try {
            renderer?.close(); pfd?.close()
            val f = File(cacheDir, "cur.pdf")
            contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(pfd!!)
            show(0)
        } catch (t: Throwable) {
            Toast.makeText(this, "PDF باز نشد: ${t.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun show(i: Int) {
        val r = renderer ?: return
        if (i < 0 || i >= r.pageCount) return
        page = i
        r.openPage(i).use { pg ->
            val scale = 3f // کیفیت بالا برای نقشه‌ها
            val w = (pg.width * scale).toInt().coerceAtMost(4000)
            val h = (pg.height * (w / pg.width.toFloat())).toInt()
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            zv.bitmap = bmp
        }
        info.text = "${page + 1} / ${r.pageCount}"
    }

    private fun jump() {
        val r = renderer ?: return
        val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; hint = "1 – ${r.pageCount}" }
        AlertDialog.Builder(this).setTitle("رفتن به صفحه").setView(et)
            .setPositiveButton("OK") { _, _ -> et.text.toString().toIntOrNull()?.let { show(it - 1) } }.show()
    }

    override fun onDestroy() { renderer?.close(); pfd?.close(); super.onDestroy() }
}
