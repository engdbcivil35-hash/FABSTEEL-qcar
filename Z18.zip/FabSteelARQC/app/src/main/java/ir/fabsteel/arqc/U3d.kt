package ir.fabsteel.arqc

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.Inflater
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * خواندن مدل سه‌بعدی U3D (داخل PDF سه‌بعدی یا فایل .u3d).
 * فقط مش پایه‌ی CLOD (بلوک 0xFFFFFF3B) رمزگشایی می‌شود؛ مختصات رأس‌ها خام‌اند و اندیس وجه‌ها با کدگذاری حسابی فشرده شده‌اند.
 */
object U3dReader {
    private const val T_MODIFIER_CHAIN = 0xFFFFFF14.toInt()
    private const val T_GROUP_NODE = 0xFFFFFF21.toInt()
    private const val T_MODEL_NODE = 0xFFFFFF22.toInt()
    private const val T_CLOD_BASE = 0xFFFFFF3B.toInt()

    fun isPdf(h: ByteArray) = h.size >= 4 && h[0] == 0x25.toByte() && h[1] == 0x50.toByte() && h[2] == 0x44.toByte() && h[3] == 0x46.toByte()
    fun isU3d(h: ByteArray) = h.size >= 4 && h[0] == 0x55.toByte() && h[1] == 0x33.toByte() && h[2] == 0x44.toByte() && h[3] == 0.toByte()

    // ---------- استخراج U3D از PDF ----------
    private fun indexOf(d: ByteArray, pat: ByteArray, from: Int): Int {
        var i = max(0, from)
        val last = d.size - pat.size
        outer@ while (i <= last) {
            for (j in pat.indices) if (d[i + j] != pat[j]) { i++; continue@outer }
            return i
        }
        return -1
    }
    private fun lastIndexOf(d: ByteArray, pat: ByteArray, from: Int): Int {
        var i = min(from, d.size - pat.size)
        outer@ while (i >= 0) {
            for (j in pat.indices) if (d[i + j] != pat[j]) { i--; continue@outer }
            return i
        }
        return -1
    }

    fun extractFromPdf(pdf: ByteArray): List<ByteArray> {
        val res = ArrayList<ByteArray>()
        val key = "/U3D".toByteArray(Charsets.ISO_8859_1)
        val obj = "obj".toByteArray(Charsets.ISO_8859_1)
        val stream = "stream".toByteArray(Charsets.ISO_8859_1)
        val endstream = "endstream".toByteArray(Charsets.ISO_8859_1)
        var pos = 0
        while (true) {
            val k = indexOf(pdf, key, pos)
            if (k < 0) break
            pos = k + 4
            // ابتدای شیء: آخرین «obj» قبل از k که «endobj» نباشد
            var o = lastIndexOf(pdf, obj, k)
            while (o >= 3 && pdf[o - 1] == 'd'.code.toByte() && pdf[o - 2] == 'n'.code.toByte() && pdf[o - 3] == 'e'.code.toByte())
                o = lastIndexOf(pdf, obj, o - 1)
            if (o < 0) continue
            val s = indexOf(pdf, stream, k)
            if (s < 0) continue
            val dict = String(pdf, o, s - o, Charsets.ISO_8859_1)
            if (!dict.contains("/Subtype") || dict.contains("/3DView") ) continue
            var ds = s + stream.size
            if (ds < pdf.size && pdf[ds] == 0x0D.toByte()) ds++
            if (ds < pdf.size && pdf[ds] == 0x0A.toByte()) ds++
            val e = indexOf(pdf, endstream, ds)
            if (e < 0) continue
            var de = e
            while (de > ds && (pdf[de - 1] == 0x0A.toByte() || pdf[de - 1] == 0x0D.toByte())) de--
            val raw = pdf.copyOfRange(ds, de)
            val data = if (dict.contains("FlateDecode")) inflate(raw) else raw
            if (data != null && isU3d(data)) res.add(data)
            pos = max(pos, e)
        }
        return res
    }

    private fun inflate(raw: ByteArray): ByteArray? {
        return try {
            val inf = Inflater()
            inf.setInput(raw)
            val out = ByteArrayOutputStream()
            val buf = ByteArray(65536)
            while (!inf.finished()) {
                val n = inf.inflate(buf)
                if (n == 0 && (inf.needsInput() || inf.needsDictionary())) break
                out.write(buf, 0, n)
            }
            inf.end()
            out.toByteArray()
        } catch (e: Exception) { null }
    }

    // ---------- بلوک‌ها ----------
    private class Blk(val type: Int, val data: ByteArray)

    private fun blocks(u: ByteArray): List<Blk> {
        val bb = ByteBuffer.wrap(u).order(ByteOrder.LITTLE_ENDIAN)
        val out = ArrayList<Blk>()
        var p = 0
        while (p + 12 <= u.size) {
            val t = bb.getInt(p); val ds = bb.getInt(p + 4); val ms = bb.getInt(p + 8)
            if (ds < 0 || ms < 0 || p.toLong() + 12 + ds > u.size) break
            out.add(Blk(t, u.copyOfRange(p + 12, p + 12 + ds)))
            p += 12 + ds + ((4 - ds % 4) % 4) + ms + ((4 - ms % 4) % 4)
        }
        return out
    }

    private class Rd(val b: ByteArray, var p: Int = 0) {
        private val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        fun u32(): Int { val v = bb.getInt(p); p += 4; return v }
        fun f32(): Float { val v = bb.getFloat(p); p += 4; return v }
        fun str(): String {
            val l = bb.getShort(p).toInt() and 0xFFFF; p += 2
            val s = String(b, p, l, Charsets.ISO_8859_1); p += l; return s
        }
    }

    // ---------- کدگشای حسابی ----------
    private class DynHist {
        var f = IntArray(8).also { it[0] = 1 }
        var total = 1
        fun update(v: Int) {
            val sym = v + 1
            if (sym > 0xFFFF || sym < 0) return
            if (sym >= f.size) f = f.copyOf(max(sym + 1, f.size * 2))
            f[sym]++; total++
            if (total >= 0x1FFF) {
                var t = 0
                for (i in f.indices) { f[i] = f[i] / 2; t += f[i] }
                f[0]++; t++
                total = t
            }
        }
    }

    private class AD(val d: ByteArray, startByte: Int) {
        var bitPos = startByte.toLong() * 8
        var low = 0; var high = 0xFFFF; var code = 0
        init { repeat(16) { code = (code shl 1) or bit() } }
        fun bit(): Int {
            val i = (bitPos ushr 3).toInt()
            val b = if (i < d.size) (d[i].toInt() shr (bitPos and 7).toInt()) and 1 else 0
            bitPos++
            return b
        }
        private fun renorm() {
            while (true) {
                if ((high and 0x8000) == (low and 0x8000)) {
                } else if ((low and 0x4000) != 0 && (high and 0x4000) == 0) {
                    low -= 0x4000; high -= 0x4000; code -= 0x4000
                } else break
                low = (low shl 1) and 0xFFFF
                high = ((high shl 1) or 1) and 0xFFFF
                code = ((code shl 1) or bit()) and 0xFFFF
            }
        }
        /** زمینه‌ی ایستا با R نماد یکنواخت؛ مقدار 0..R-1 */
        fun stat(r: Int): Int {
            val rng = (high - low + 1).toLong()
            var v = (((code - low + 1).toLong() * r - 1) / rng).toInt()
            if (v < 0) v = 0
            if (v >= r) v = r - 1
            val nh = low + ((rng * (v + 1)) / r).toInt() - 1
            val nl = low + ((rng * v) / r).toInt()
            low = nl; high = nh
            renorm()
            return v
        }
        private fun u8raw(): Int {
            val v = stat(256)
            var r = 0
            for (i in 0 until 8) if ((v shr i) and 1 != 0) r = r or (1 shl (7 - i))
            return r
        }
        fun dyn(h: DynHist): Int {
            val rng = (high - low + 1).toLong()
            val value = (((code - low + 1).toLong() * h.total - 1) / rng)
            var cum = 0; var k = 0
            while (k < h.f.size - 1 && cum + h.f[k] <= value) { cum += h.f[k]; k++ }
            val lo = cum; val hi = cum + h.f[k]
            high = low + ((rng * hi) / h.total).toInt() - 1
            low = low + ((rng * lo) / h.total).toInt()
            renorm()
            val v: Int
            if (k == 0) {
                h.f[0]++; h.total++
                var x = 0
                for (i in 0 until 4) x = x or (u8raw() shl (8 * i))
                v = x
            } else v = k - 1
            h.update(v)
            return v
        }
    }

    private class MeshData(val pos: FloatArray, val faces: IntArray)

    private fun decodeBaseMesh(b: ByteArray): Pair<String, MeshData>? {
        val r = Rd(b)
        val name = r.str()
        r.u32() // chain index
        val nf = r.u32(); val np = r.u32(); val nn = r.u32()
        val nd = r.u32(); val ns = r.u32(); val nt = r.u32()
        if (nf < 0 || np <= 0 || nn < 0 || nf > 5_000_000 || np > 5_000_000) return null
        if (r.p + np.toLong() * 12 + nn.toLong() * 12 + (nd + ns + nt).toLong() * 16 > b.size) return null
        val pos = FloatArray(np * 3) { r.f32() }
        r.p += nn * 12 + nd * 16 + ns * 16 + nt * 16
        val ad = AD(b, r.p)
        val sh = DynHist()
        val faces = IntArray(nf * 3)
        for (f in 0 until nf) {
            ad.dyn(sh) // شماره‌ی shading
            for (c in 0 until 3) {
                val pi = ad.stat(np)
                if (nn > 0) ad.stat(nn)
                if (nd > 0) ad.stat(nd)
                if (ns > 0) ad.stat(ns)
                if (nt > 0) ad.stat(nt)
                faces[f * 3 + c] = pi
            }
        }
        return name to MeshData(pos, faces)
    }

    // ---------- گره‌ها ----------
    private class Node(val name: String, val parent: String, val m: FloatArray, val mesh: String?)

    private fun parseNodes(blks: List<Blk>): List<Node> {
        val out = ArrayList<Node>()
        for (bl in blks) {
            if (bl.type != T_MODIFIER_CHAIN) continue
            try {
                val r = Rd(bl.data)
                r.str()
                val ctype = r.u32()
                val attr = r.u32()
                if (ctype != 0) continue
                if (attr and 1 != 0) r.p += 16
                if (attr and 2 != 0) r.p += 24
                r.p = (r.p + 3) and 3.inv() // تراز ۴ بایتی قبل از شمارنده
                r.u32() // تعداد مدیفایرها
                for (sub in blocks(bl.data.copyOfRange(r.p, bl.data.size))) {
                    if (sub.type != T_MODEL_NODE && sub.type != T_GROUP_NODE) continue
                    val s = Rd(sub.data)
                    val nm = s.str()
                    val pc = s.u32()
                    var pname = ""
                    var mat = floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)
                    for (i in 0 until pc) {
                        val pn = s.str()
                        val m = FloatArray(16) { s.f32() }
                        if (i == 0) { pname = pn; mat = m }
                    }
                    val mesh = if (sub.type == T_MODEL_NODE) s.str() else null
                    out.add(Node(nm, pname, mat, mesh))
                }
            } catch (e: Exception) { }
        }
        return out
    }

    private fun mul(a: FloatArray, b: FloatArray): FloatArray { // ستونی 4x4: a*b
        val r = FloatArray(16)
        for (c in 0..3) for (rw in 0..3) {
            var s = 0f
            for (k in 0..3) s += a[k * 4 + rw] * b[c * 4 + k]
            r[c * 4 + rw] = s
        }
        return r
    }

    // ---------- ساخت مدل ----------
    fun build(u3d: List<ByteArray>): IfcModel {
        val meshes = HashMap<String, MeshData>()
        val nodes = ArrayList<Node>()
        for (u in u3d) {
            val bl = blocks(u)
            for (b in bl) if (b.type == T_CLOD_BASE) {
                try { decodeBaseMesh(b.data)?.let { meshes[it.first] = it.second } } catch (e: Exception) { }
            }
            nodes.addAll(parseNodes(bl))
        }
        if (meshes.isEmpty()) throw IllegalStateException("مدل سه‌بعدی در PDF پیدا نشد یا پشتیبانی نمی‌شود")
        val byName = HashMap<String, Node>()
        for (n in nodes) byName[n.name] = n
        val cache = HashMap<String, FloatArray>()
        fun world(n: Node, depth: Int = 0): FloatArray {
            cache[n.name]?.let { return it }
            val p = byName[n.parent]
            val w = if (p != null && depth < 32) mul(world(p, depth + 1), n.m) else n.m
            cache[n.name] = w
            return w
        }
        // فهرست نمونه‌ها: (نام، مش، ماتریس)
        class Inst(val name: String, val mesh: MeshData, val w: FloatArray)
        val insts = ArrayList<Inst>()
        for (n in nodes) {
            val md = n.mesh?.let { meshes[it] } ?: continue
            insts.add(Inst(n.name, md, world(n)))
        }
        if (insts.isEmpty()) for ((k, v) in meshes) insts.add(Inst(k, v, floatArrayOf(1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 1f)))

        // مختصات جهانی (Z بالا) → متر؟
        val worldPts = ArrayList<FloatArray>()
        var mn = floatArrayOf(Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE)
        var mx = floatArrayOf(-Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE)
        for (ins in insts) {
            val p = ins.mesh.pos; val w = ins.w
            val o = FloatArray(p.size)
            var i = 0
            while (i < p.size) {
                val x = p[i]; val y = p[i + 1]; val z = p[i + 2]
                o[i] = w[0] * x + w[4] * y + w[8] * z + w[12]
                o[i + 1] = w[1] * x + w[5] * y + w[9] * z + w[13]
                o[i + 2] = w[2] * x + w[6] * y + w[10] * z + w[14]
                for (a in 0..2) { mn[a] = min(mn[a], o[i + a]); mx[a] = max(mx[a], o[i + a]) }
                i += 3
            }
            worldPts.add(o)
        }
        val ext = max(mx[0] - mn[0], max(mx[1] - mn[1], mx[2] - mn[2]))
        val scale = if (ext > 500f) 0.001f else 1f // اگر ابعاد خیلی بزرگ بود یعنی میلی‌متر است

        // تبدیل به دستگاه AR (Y بالا) و انتقال به گوشه‌ی مینیمم: (x,y,z) -> (x, z, -y)
        val sx = (mx[0] - mn[0]) * scale; val sy = (mx[2] - mn[2]) * scale; val sz = (mx[1] - mn[1]) * scale
        val members = ArrayList<Member>()
        for ((idx, ins) in insts.withIndex()) {
            val wp = worldPts[idx]
            val np = wp.size / 3
            val X = FloatArray(np); val Y = FloatArray(np); val Z = FloatArray(np)
            for (i in 0 until np) {
                X[i] = (wp[i * 3] - mn[0]) * scale
                Y[i] = (wp[i * 3 + 2] - mn[2]) * scale
                Z[i] = -(wp[i * 3 + 1] - mx[1]) * scale
            }
            members.add(makeMember(ins.name, X, Y, Z, ins.mesh.faces))
        }
        return IfcModel(members, floatArrayOf(sx, sy, sz))
    }

    private fun makeMember(name: String, X: FloatArray, Y: FloatArray, Z: FloatArray, faces: IntArray): Member {
        val nf = faces.size / 3
        // یکی‌کردن رأس‌های هم‌مختصات
        val vid = HashMap<Long, Int>()
        val rep = IntArray(X.size)
        for (i in X.indices) {
            val key = (Math.round(X[i] * 10000f).toLong() and 0x1FFFFF) or
                ((Math.round(Y[i] * 10000f).toLong() and 0x1FFFFF) shl 21) or
                ((Math.round(Z[i] * 10000f).toLong() and 0x1FFFFF) shl 42)
            rep[i] = vid.getOrPut(key) { i }
        }
        val nx = FloatArray(nf); val ny = FloatArray(nf); val nz = FloatArray(nf)
        val tris = FloatArray(nf * 9)
        val edgeTris = HashMap<Long, IntArray>() // کلید → [مثلث1, مثلث2 یا -1, شمارنده]
        val samples = ArrayList<Float>()
        for (f in 0 until nf) {
            val a = faces[f * 3]; val b = faces[f * 3 + 1]; val c = faces[f * 3 + 2]
            if (a >= X.size || b >= X.size || c >= X.size) continue
            tris[f * 9] = X[a]; tris[f * 9 + 1] = Y[a]; tris[f * 9 + 2] = Z[a]
            tris[f * 9 + 3] = X[b]; tris[f * 9 + 4] = Y[b]; tris[f * 9 + 5] = Z[b]
            tris[f * 9 + 6] = X[c]; tris[f * 9 + 7] = Y[c]; tris[f * 9 + 8] = Z[c]
            val ux = X[b] - X[a]; val uy = Y[b] - Y[a]; val uz = Z[b] - Z[a]
            val vx = X[c] - X[a]; val vy = Y[c] - Y[a]; val vz = Z[c] - Z[a]
            var cx = uy * vz - uz * vy; var cy = uz * vx - ux * vz; var cz = ux * vy - uy * vx
            val l = sqrt(cx * cx + cy * cy + cz * cz)
            if (l < 1e-12f) continue
            nx[f] = cx / l; ny[f] = cy / l; nz[f] = cz / l
            if (f % max(1, nf / 40) == 0) { samples.add((X[a] + X[b] + X[c]) / 3); samples.add((Y[a] + Y[b] + Y[c]) / 3); samples.add((Z[a] + Z[b] + Z[c]) / 3) }
            val ids = intArrayOf(rep[a], rep[b], rep[c])
            for (e in 0..2) {
                val p = ids[e]; val q = ids[(e + 1) % 3]
                if (p == q) continue
                val key = (min(p, q).toLong() shl 32) or max(p, q).toLong()
                val arr = edgeTris.getOrPut(key) { intArrayOf(f, -1, 0) }
                if (arr[2] == 1 && arr[1] == -1) arr[1] = f
                arr[2]++
            }
        }
        val edges = ArrayList<Float>()
        for ((key, arr) in edgeTris) {
            val p = (key shr 32).toInt(); val q = (key and 0xFFFFFFFFL).toInt()
            var keep = arr[2] != 2
            if (!keep) {
                val t1 = arr[0]; val t2 = arr[1]
                val dot = nx[t1] * nx[t2] + ny[t1] * ny[t2] + nz[t1] * nz[t2]
                keep = dot < 0.94f
            }
            if (keep) {
                edges.add(X[p]); edges.add(Y[p]); edges.add(Z[p])
                edges.add(X[q]); edges.add(Y[q]); edges.add(Z[q])
            }
        }
        return Member(name, false, edges.toFloatArray(), tris, samples.toFloatArray())
    }
}
